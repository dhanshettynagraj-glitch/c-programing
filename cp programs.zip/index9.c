#include <stdio.h>
int main() {
    int a, b;
    printf("enter the number: ");
    scanf("%d %d", &a, &b);
    if(a > b)
      printf("%d is larger", a);
    else
      printf("%d is larger", b);
    return 0;
}