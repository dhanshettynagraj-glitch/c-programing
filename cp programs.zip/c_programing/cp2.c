#include<stdio.h>
int main()
{
    int a = 45;
    float b = 12.9876;
    char c ='Z';
    printf("integer:%d\n",a);
    printf("float(2 decimal):%.2f\n",b);
    printf("float(5 decimal):%.5f\n",b);
    printf("character:%c\n",c);
    return 0;
}