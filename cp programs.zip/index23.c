#include<stdio.h>
int main(){ 
    int number, i=1, sum=0;
    printf("Enter a positive integer: ");
    scanf("%d", &number);
    while(i<=n)

    {
        sum=sum+i;
        i++;
    }
    printf("sum=%d",sum);
    return 0;
}