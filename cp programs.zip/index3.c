#include <stdio.h>
int main() {
    int a, b, sum;
    printf("enter two number: ");
    scanf("%d %d" , &a &b);
        sum = a + b;   
     printf("sum = %d" , sum);
    return 0;
}
