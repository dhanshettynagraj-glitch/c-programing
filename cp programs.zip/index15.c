#include<stdio.h>
int main(){
    int a=10
    a--
    printf("value of a=%d\n",a);
    return 0;

}